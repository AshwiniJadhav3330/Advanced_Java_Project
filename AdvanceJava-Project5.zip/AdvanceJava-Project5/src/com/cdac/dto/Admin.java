package com.cdac.dto;

public class Admin 
{
	
		
		
		private int AdminId;
		
		private String AdminPass;

		
		
		
		public Admin() {
			super();
			// TODO Auto-generated constructor stub
		}

		public int getAdminId() {
			return AdminId;
		}

		public void setAdminId(int adminId) {
			AdminId = adminId;
		}

		public String getAdminPass() {
			return AdminPass;
		}

		public void setAdminPass(String adminPass) {
			AdminPass = adminPass;
		}
		
		

}