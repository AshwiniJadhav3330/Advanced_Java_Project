package com.cdac.service;

import java.util.List;

import com.cdac.dto.LunchBox;

public interface LunchBoxService {
	void addExpense(LunchBox expense);
	void removeExpense(int NoOfItem);
	LunchBox findExpenxe(int NoOfItem);
	void modifyExpense(LunchBox expense);
	List<LunchBox> selectAll(int userId);
}
