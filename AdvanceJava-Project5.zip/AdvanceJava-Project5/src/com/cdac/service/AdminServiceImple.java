package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AdminDao;
import com.cdac.dao.AdminDaoImple;
import com.cdac.dto.Admin;
import com.cdac.dto.LunchBox;

@Service
public class AdminServiceImple implements AdminService
{
	@Autowired
	private AdminDaoImple adminDaoImple;
	@Override
	public Admin findExpenxe(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<LunchBox> selectAll(LunchBox lunchBox) {
		// TODO Auto-generated method stub
		return adminDaoImple.selectAll(lunchBox);
	}
	
	
}
