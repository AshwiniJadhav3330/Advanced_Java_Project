package com.cdac.dao;

import java.util.List;

import com.cdac.dto.LunchBox;

public interface LunchBoxDao {
	void insertExpense(LunchBox expense);
	void deleteExpense(int expenseId);
	LunchBox selectExpenxe(int expenseId);
	void updateExpense(LunchBox expense);
	List<LunchBox> selectAll(int userId);
}
