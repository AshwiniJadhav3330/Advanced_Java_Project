package Interfaces;

import javax.swing.JMenuItem;

public interface IMenu {

	static JMenuItem exitItem = new JMenuItem("Exit");
	static JMenuItem saveasItem = new JMenuItem("Save tables as..");
	static JMenuItem helpItem = new JMenuItem("Help");;
	static JMenuItem aboutItem = new JMenuItem("About");;
	static JMenuItem databaseSettingsItem = new JMenuItem("Databse Settings"); ;
	static JMenuItem changePassItem = new JMenuItem("Change Password");
	
}
