package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cdac.dto.LunchBox;
import com.cdac.dto.User;
import com.cdac.service.AdminServiceImple;
import com.cdac.service.LunchBoxService;

@Controller
@SessionAttributes("userName")
public class LunchBoxController {
	
	@Autowired
	private LunchBoxService expenseService;
	
	@Autowired
	private AdminServiceImple adminServiceImple;
	
	@RequestMapping(value = "/prep_expense_add_form.htm",method = RequestMethod.GET)
	public String prepExpenseAddForm(ModelMap map) {
		map.put("expense", new LunchBox());
		return "expense_add_form";
	}
	
	@RequestMapping(value = "/expense_add.htm",method = RequestMethod.POST)
	public String expenseAdd(LunchBox expense,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		expense.setUserId(userId); 
		expenseService.addExpense(expense);
		return "home";
	}
	
	@RequestMapping(value = "/expense_list.htm",method = RequestMethod.GET)
	public String allExpenses(ModelMap map,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		List<LunchBox> li = expenseService.selectAll(userId);
		map.put("expList", li);
		return "expense_list";
	}
	
	@RequestMapping(value = "/expense_delete.htm",method = RequestMethod.GET)
	public String expenseDelete(@RequestParam int expenseId,ModelMap map,HttpSession session) {
		
		expenseService.removeExpense(expenseId); 
		
		int userId = ((User)session.getAttribute("user")).getUserId();
		List<LunchBox> li = expenseService.selectAll(userId);
		map.put("expList", li);
		return "expense_list";
	}
	
	@RequestMapping(value = "/expense_update_form.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int expenseId,ModelMap map) {
		
		LunchBox exp = expenseService.findExpenxe(expenseId);
		map.put("expense", exp);
		
		return "expense_update_form";
	}
	
	@RequestMapping(value = "/expense_update.htm",method = RequestMethod.POST)
	public String expenseUpdate(LunchBox expense,ModelMap map,HttpSession session) {
		
		int userId = ((User)session.getAttribute("user")).getUserId();
		expense.setUserId(userId);
		expenseService.modifyExpense(expense);
			
		List<LunchBox> li = expenseService.selectAll(userId);
		map.put("expList", li);
		return "expense_list";
	}
	
	
	@RequestMapping(value = "/lunchList.htm")
	public String lunchList(LunchBox lunchBox,ModelMap map) {
		List<LunchBox>li=adminServiceImple.selectAll(lunchBox);
		map.put("lunchList", li);
		return "lunchList";
	}
}
