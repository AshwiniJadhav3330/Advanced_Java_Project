package com.cdac.service;

import java.util.List;

import com.cdac.dto.Admin;
import com.cdac.dto.LunchBox;


public interface AdminService
{
	Admin findExpenxe(int userId);
	List<LunchBox> selectAll(LunchBox lunchBox);
}
