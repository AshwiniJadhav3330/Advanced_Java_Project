package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.LunchBox;

@Repository
public class LunchBoxDaoImple implements LunchBoxDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void insertExpense(LunchBox expense) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(expense);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	@Override
	public void deleteExpense(int NoOfItem) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new LunchBox(NoOfItem));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	@Override
	public LunchBox selectExpenxe(int NoOfItem) {
		LunchBox expense = hibernateTemplate.execute(new HibernateCallback<LunchBox>() {

			@Override
			public LunchBox doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				LunchBox ex = (LunchBox)session.get(LunchBox.class, NoOfItem);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return expense;
	}

	@Override
	public void updateExpense(LunchBox expense) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
//				Expense ex = (Expense)session.get(Expense.class, expense.getExpenseId());
//				ex.setItemName(expense.getItemName());
//				ex.setPrice(expense.getPrice());
//				ex.setPurchaseDate(expense.getPurchaseDate()); 
				
				session.update(expense);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public List<LunchBox> selectAll(int userId) {
		List<LunchBox> expList = hibernateTemplate.execute(new HibernateCallback<List<LunchBox>>() {

			@Override
			public List<LunchBox> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from LunchBox where userId = ?");
				q.setInteger(0, userId);
				List<LunchBox> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return expList;
	}

}
