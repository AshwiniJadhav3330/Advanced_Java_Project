package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.LunchBoxDao;
import com.cdac.dto.LunchBox;

@Service
public class LunchBoxServiceImple implements LunchBoxService {
	
	@Autowired
	private LunchBoxDao expenseDao;

	@Override
	public void addExpense(LunchBox expense) {
		expenseDao.insertExpense(expense);
	}

	@Override
	public void removeExpense(int NoOfItem) {
		expenseDao.deleteExpense(NoOfItem);
	}

	@Override
	public LunchBox findExpenxe(int NoOfItem) {
		return expenseDao.selectExpenxe(NoOfItem);
	}

	@Override
	public void modifyExpense(LunchBox expense) {
		expenseDao.updateExpense(expense);
	}

	@Override
	public List<LunchBox> selectAll(int userId) {
		return expenseDao.selectAll(userId);
	}

}
