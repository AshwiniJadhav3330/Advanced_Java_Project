package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Admin;
import com.cdac.dto.LunchBox;

//import com.cdac.dto.User;

public interface AdminDao 
{
	boolean checkUser(Admin admin);
	List<LunchBox> selectAll(LunchBox lunchBox);
}
