package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/*
@Entity
@Table(name = "expensee")
public class Expense {
	@Id
	@Column(name = "expense_id")
	@GeneratedValue
	private int expenseId;
	@Column(name = "item_name")
	private String itemName;
	private float price;
	@Column(name = "purchase_date")
	private String purchaseDate;
	private int userId;
	public Expense() {
		super();
		// TODO Auto-generated constructor stub
	}
*/
@Entity
@Table(name = "meal")
public class LunchBox
{
	



	@Id
	@GeneratedValue
	private int NoOfItem;
	
	private String MealName;
	private long mobNum;
	private String adress;
	
	private int userId;
	
	
	


	

	public long getMobNum() {
		return mobNum;
	}







	public void setMobNum(long mobNum) {
		this.mobNum = mobNum;
	}







	public LunchBox() {
		super();
		// TODO Auto-generated constructor stub
	}







	public LunchBox(int noOfItem) {
		super();
		NoOfItem = noOfItem;
	}







	
	



	public int getNoOfItem() {
		return NoOfItem;
	}


	public void setNoOfItem(int noOfItem) {
		NoOfItem = noOfItem;
	}


	public String getMealName() {
		return MealName;
	}


	public void setMealName(String mealName) {
		MealName = mealName;
	}


	public String getAdress() {
		return adress;
	}


	public void setAdress(String adress) {
		this.adress = adress;
	}







	public int getUserId() {
		return userId;
	}







	public void setUserId(int userId) {
		this.userId = userId;
	}


	
	
	
}


